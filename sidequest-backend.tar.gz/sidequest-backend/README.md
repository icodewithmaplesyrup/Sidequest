# Sidequest Backend

Node/Express API for the Sidequest app (sidequest7.html).

## Project layout

```
sidequest-backend/
├── server.js               ← Production entry point (Express)
├── .env.example            ← Copy to .env and fill in values
│
├── db/
│   ├── schema.sql          ← PostgreSQL schema (run once)
│   ├── migrate.js          ← Migration runner: node db/migrate.js
│   └── pool.js             ← pg connection pool
│
├── middleware/
│   ├── auth.js             ← JWT helpers (requireAuth, requireMod, signToken)
│   └── upload.js           ← Multer video upload config
│
├── routes/
│   ├── auth.js             ← POST /api/auth/google|apple|email/signup|signin
│   ├── quests.js           ← Quest CRUD, video upload, completions
│   ├── review.js           ← Mod queue, vote, decision engine
│   └── users.js            ← Profile, leaderboard, cosmetics
│
├── scripts/
│   └── setup-debian.sh     ← One-shot Debian 12 server provisioning
│
└── dev/
    └── dev-server.js       ← Zero-native-dep debug server for sidequest7.html
```

---

## Quest pipeline

```
User submits form
      │
      ▼
  pending_review          ← quest row created, no video yet
      │
  (user attaches video)
      │
      ▼
   in_review              ← visible in mod queue
      │
  (moderators vote)
      │
  ┌───┴────────────────┐
  │  < MIN_VOTES yet   │   wait for more votes
  └───────────────────►│
      │
  ┌───┴────────────────────────────────────┐
  │  majority rejected  → status=rejected  │
  │  otherwise          → status=posted    │
  │                       xp_final set     │
  └────────────────────────────────────────┘
```

**Key numbers** (configurable via `.env`):
| Variable | Default | Meaning |
|---|---|---|
| `MIN_VOTES_FOR_DECISION` | `5` | Votes needed before auto-decision |
| `REVIEWER_XP_REWARD` | `15` | XP a mod earns per vote |
| `MAX_VIDEO_SIZE_MB` | `100` | Upload cap |

---

## Quick start (dev)

```bash
# 1. Install
npm install

# 2. Start the debug server
npm run dev
# → http://localhost:4000  (serves sidequest7.html with API wired in)
# → http://localhost:4000/debug/state  (full state dump)
```

The dev server uses a plain JSON file (`dev/sidequest-dev.json`) — no Postgres, no Redis.

### Test the full pipeline in dev

```bash
# 1. Submit a quest
curl -s -X POST http://localhost:4000/api/auth/dev-login \
  -H 'Content-Type: application/json' \
  -d '{"username":"alice"}' | jq .token

# 2. Create quest (use token from above)
curl -s -X POST http://localhost:4000/api/quests \
  -H 'Content-Type: application/json' \
  -H 'Authorization: Bearer <TOKEN>' \
  -d '{"title":"Did a backflip at Starbucks","difficulty":"hard"}' | jq .

# 3. Simulate video attached → moves to in_review
curl -s -X POST http://localhost:4000/api/quests/<QUEST_ID>/video-ready \
  -H 'Authorization: Bearer <ALICE_TOKEN>'

# 4. Vote as mod (repeat 5× with mod_user token to trigger auto-decision)
curl -s -X POST http://localhost:4000/api/auth/dev-login \
  -d '{"username":"mod_user"}' -H 'Content-Type: application/json' | jq .token

curl -s -X POST http://localhost:4000/api/review/<QUEST_ID>/vote \
  -H 'Content-Type: application/json' \
  -H 'Authorization: Bearer <MOD_TOKEN>' \
  -d '{"vote":"approved"}'
```

After 5 `approved` votes the quest becomes `posted` and appears on `/api/quests` (feed) and `/api/quests/map`.

---

## Production setup (Debian 12)

```bash
sudo bash scripts/setup-debian.sh

# After script completes:
cp /tmp/sidequest.env /opt/sidequest/.env
nano /opt/sidequest/.env          # fill JWT_SECRET, GOOGLE_CLIENT_ID, etc.

cd /opt/sidequest
npm install --omit=dev
node db/migrate.js

pm2 start ecosystem.config.js
pm2 save
```

### What the setup script does
- Installs Node 20 LTS, PostgreSQL 15 + PostGIS, Redis, Nginx, PM2
- Creates a `sidequest` system user (no shell, no home)
- Sets UFW rules (SSH + Nginx only)
- Writes an Nginx reverse-proxy config (port 3000 → HTTP)
- Configures PM2 cluster mode (one worker per CPU core)
- Sets up log rotation at `/var/log/sidequest/`
- Adds an hourly cron to warn when `/var/sidequest/uploads` exceeds 80% of the 256 GB SSD

---

## API reference

### Auth
| Method | Path | Auth | Notes |
|---|---|---|---|
| POST | `/api/auth/google` | — | Body: `{ id_token }` (Google GIS) |
| POST | `/api/auth/apple` | — | **⚠ Not implemented** — see routes/auth.js |
| POST | `/api/auth/email/signup` | — | Body: `{ username, email, password }` |
| POST | `/api/auth/email/signin` | — | Body: `{ email, password }` |

### Quests
| Method | Path | Auth | Notes |
|---|---|---|---|
| GET | `/api/quests` | optional | Paginated feed of `posted` quests |
| GET | `/api/quests/map` | — | Compact payload for map pins |
| GET | `/api/quests/:id` | optional | Single quest |
| POST | `/api/quests` | ✓ | Submit → `pending_review` |
| POST | `/api/quests/:id/video` | ✓ | Attach video → `in_review` |
| POST | `/api/quests/:id/complete` | ✓ | Record completion, award XP |

### Review (mod only)
| Method | Path | Auth | Notes |
|---|---|---|---|
| GET | `/api/review/queue` | mod | Quests not yet voted on by this mod |
| POST | `/api/review/:id/vote` | mod | Body: `{ vote, xp_suggest? }` |
| GET | `/api/review/stats` | mod | Personal vote stats |

### Users
| Method | Path | Auth | Notes |
|---|---|---|---|
| GET | `/api/users/me` | ✓ | Full profile + level + royalties |
| PATCH | `/api/users/me` | ✓ | Update username / bio / cosmetics |
| GET | `/api/users/me/quests` | ✓ | User's submitted quests |
| GET | `/api/users/me/completions` | ✓ | Completed quests |
| GET | `/api/users/leaderboard` | — | Top 100 by XP |
| GET | `/api/users/:username` | — | Public profile |

---

## Known gaps / TODOs

1. **Apple Sign-In** — server-side token exchange is stubbed in `routes/auth.js`.
   Install `apple-signin-auth` and complete the TODO block.
   Requires a `.p8` private key from your Apple Developer account.

2. **FFmpeg video processing** — `routes/quests.js` uploads the raw file but does
   not transcode, generate thumbnails, or validate duration.
   Add a BullMQ job queue (Redis-backed) + an FFmpeg worker for production.

3. **Push notifications** — the review XP award happens but there's no push
   delivery. Wire up Firebase Cloud Messaging or APNs when the native app ships.

4. **Refresh tokens** — the `refresh_tokens` table exists in `schema.sql` but the
   route to exchange a refresh token for a new access token is not implemented.
