'use strict';
const jwt = require('jsonwebtoken');

/**
 * requireAuth — hard gate, 401 if no valid token.
 */
function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing authorization token' });
  }
  const token = header.slice(7);
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    return next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

/**
 * optionalAuth — attaches user if token present and valid, otherwise continues.
 * Use for public routes that show extra data when logged in.
 */
function optionalAuth(req, res, next) {
  const header = req.headers.authorization;
  if (header && header.startsWith('Bearer ')) {
    try {
      req.user = jwt.verify(header.slice(7), process.env.JWT_SECRET);
    } catch (_) { /* ignore */ }
  }
  return next();
}

/**
 * requireMod — must be authenticated AND have is_mod = true.
 */
function requireMod(req, res, next) {
  requireAuth(req, res, () => {
    if (!req.user.is_mod) {
      return res.status(403).json({ error: 'Moderator access required' });
    }
    return next();
  });
}

/**
 * Sign a short-lived access token.
 */
function signToken(user) {
  return jwt.sign(
    { sub: user.id, username: user.username, is_mod: user.is_mod },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRY || '7d' }
  );
}

module.exports = { requireAuth, optionalAuth, requireMod, signToken };
